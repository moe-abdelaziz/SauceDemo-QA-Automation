import WelcomePage from '../pages/WelcomePage'
import LoginPage from '../pages/LoginPage'
import MyProductsPage from '../pages/ProductsPage' 
import {CREDENTIALS} from '../data/Constants'
import LogoutPage from '../pages/LogoutPage'
import CartPage from '../pages/CartPage'


fixture('Sauce Demo feature testing')
    .page('https://www.saucedemo.com/')
   
    test('01 - User can login using valid credentials', async t => {
    await t 
        .click(WelcomePage.loginButton)
        .typeText(LoginPage.usernameField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginButton)
    
    await t.expect(MyProductsPage.inventoryList.exists).ok()

})

    test('02 - User can not login using invalid password', async t => {
    await t 
        .click(WelcomePage.loginButton)
        .typeText(LoginPage.usernameField, CREDENTIALS.INVALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.INVALID_USER.PASSWORD)
        .click(LoginPage.loginButton)
        
    await t.expect(LoginPage.errorButton.exists).ok()
    await t.expect(LoginPage.errorMsg.exists).ok()
    

})

    test('03 - User logs out', async t => {
    await t 
        .click(WelcomePage.loginButton)
        .typeText(LoginPage.usernameField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginButton)

    await t.expect(MyProductsPage.inventoryList.exists).ok()

        .click(LogoutPage.menuButton)
        .click(LogoutPage.logoutButton)
        
    await t.expect(LogoutPage.loginButton.exists).ok()
    
    

})


test('04 - User navigates to shopping cart', async t => {
    await t 
        .click(WelcomePage.loginButton)
        .typeText(LoginPage.usernameField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginButton)

    await t.expect(MyProductsPage.inventoryList.exists).ok()

        .click(CartPage.cartButton)

    await t.expect(CartPage.cartButton.exists).ok()
    
    

})

test('05 - User adds item to shopping cart', async t => {
    await t 
        .click(WelcomePage.loginButton)
        .typeText(LoginPage.usernameField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginButton)

    //await t.expect(MyProductsPage.inventoryList.exists).ok()

       .click(CartPage.addToCartbutton)
       .click(CartPage.cartButton)
       .click(CartPage.cartQ)

    await t.expect(CartPage.cartQ.innerText).eql('1')

 
    
    

})
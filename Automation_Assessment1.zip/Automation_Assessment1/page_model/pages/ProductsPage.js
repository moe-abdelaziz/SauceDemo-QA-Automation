import {Selector} from 'testcafe'

class MyProductsPage {
    constructor (){
        this.inventoryList = Selector('.inventory_list')
        //this.pageContainer = Selector('inventory_container')
        
    }
}

export default new MyProductsPage()

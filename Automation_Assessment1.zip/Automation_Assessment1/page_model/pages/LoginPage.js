import {Selector} from 'testcafe'

class LoginPage {
    constructor (){
        this.usernameField = Selector('input[name="user-name"]')
        this.passwordField = Selector('input[name="password"]')
        this.loginButton   = Selector('.btn_action')
        this.errorButton   = Selector('.error-button')
        this.errorMsg      = Selector('#login_button_container h3').withText('Epic sadface: Username and password do not match any user in this service')
      

    }
}


export default new LoginPage()


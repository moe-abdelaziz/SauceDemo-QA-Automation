import {Selector} from 'testcafe'

class CartPage {
    constructor (){
        this.usernameField = Selector('input[name="user-name"]')
        this.passwordField = Selector('input[name="password"]')
        this.loginButton   = Selector('.btn_action')
        this.errorButton   = Selector('.error-button')
        this.errorMsg      = Selector('#login_button_container h3').withText('Epic sadface: Username and password do not match any user in this service')
        this.addToCartbutton = Selector('#inventory_container').nth(1).find('button').withText('ADD TO CART')
        this.cartButton    = Selector('#shopping_cart_container a svg path')
        this.cartQ = Selector('#shopping_cart_container span')
        //this.itemName      = Selector('#item_4_title_link').withText('Sauce Labs Backpack') 
       //this.itemName      = Selector('#item_2_title_link') 
       // this.itemName      = Selector('#item_3_title_link') 
      //  this.itemName      = Selector('#item_4_title_link')   
      ///  this.itemName      = Selector('#item_5_title_link') 
      //  this.itemName      = Selector('#item_6_title_link')       
      

    }
}


export default new CartPage()
import {Selector} from 'testcafe'

class WelcomePage {
    constructor() {
        this.loginButton = Selector('.btn_action')
    }
}

export default new WelcomePage()

